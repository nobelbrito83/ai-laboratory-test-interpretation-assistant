import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Reference Ranges
  const REFERENCE_RANGES = {
    // CBC
    hemoglobin: { range: [13, 17], unit: "g/dL", category: "CBC", label: "Hemoglobin" },
    rbc_count: { range: [4.5, 5.9], unit: "million cells/µL", category: "CBC", label: "RBC Count" },
    wbc_count: { range: [4000, 11000], unit: "cells/µL", category: "CBC", label: "WBC Count" },
    platelet_count: { range: [150000, 450000], unit: "/µL", category: "CBC", label: "Platelet Count" },
    hematocrit: { range: [38, 50], unit: "%", category: "CBC", label: "Hematocrit" },
    mcv: { range: [80, 100], unit: "fL", category: "CBC", label: "MCV" },
    mch: { range: [27, 33], unit: "pg", category: "CBC", label: "MCH" },
    mchc: { range: [32, 36], unit: "g/dL", category: "CBC", label: "MCHC" },
    rdw: { range: [11, 15], unit: "%", category: "CBC", label: "RDW" },

    // WBC Differential
    neutrophils: { range: [40, 70], unit: "%", category: "WBC Differential", label: "Neutrophils" },
    lymphocytes: { range: [20, 45], unit: "%", category: "WBC Differential", label: "Lymphocytes" },
    monocytes: { range: [2, 10], unit: "%", category: "WBC Differential", label: "Monocytes" },
    eosinophils: { range: [1, 6], unit: "%", category: "WBC Differential", label: "Eosinophils" },
    basophils: { range: [0, 2], unit: "%", category: "WBC Differential", label: "Basophils" },

    // Liver Function
    alt: { range: [7, 56], unit: "U/L", category: "Liver Function", label: "ALT" },
    ast: { range: [10, 40], unit: "U/L", category: "Liver Function", label: "AST" },
    alp: { range: [44, 147], unit: "IU/L", category: "Liver Function", label: "ALP" },
    total_bilirubin: { range: [0.1, 1.2], unit: "mg/dL", category: "Liver Function", label: "Total Bilirubin" },
    direct_bilirubin: { range: [0, 0.3], unit: "mg/dL", category: "Liver Function", label: "Direct Bilirubin" },
    albumin: { range: [3.5, 5.0], unit: "g/dL", category: "Liver Function", label: "Albumin" },
    total_protein: { range: [6, 8.3], unit: "g/dL", category: "Liver Function", label: "Total Protein" },

    // Kidney Function
    creatinine: { range: [0.6, 1.3], unit: "mg/dL", category: "Kidney Function", label: "Creatinine" },
    urea: { range: [7, 20], unit: "mg/dL", category: "Kidney Function", label: "Urea" },
    blood_urea_nitrogen: { range: [7, 25], unit: "mg/dL", category: "Kidney Function", label: "Blood Urea Nitrogen" },
    uric_acid: { range: [3.5, 7.2], unit: "mg/dL", category: "Kidney Function", label: "Uric Acid" },

    // Blood Sugar
    fasting_glucose: { range: [70, 100], unit: "mg/dL", category: "Blood Sugar", label: "Fasting Glucose" },
    post_meal_glucose: { range: [0, 140], unit: "mg/dL", category: "Blood Sugar", label: "Post Meal Glucose" },
    hba1c: { range: [4, 5.6], unit: "%", category: "Blood Sugar", label: "HbA1c" },

    // Lipid Profile
    total_cholesterol: { range: [0, 200], unit: "mg/dL", category: "Lipid Profile", label: "Total Cholesterol" },
    ldl: { range: [0, 100], unit: "mg/dL", category: "Lipid Profile", label: "LDL" },
    hdl: { range: [40, 100], unit: "mg/dL", category: "Lipid Profile", label: "HDL" },
    triglycerides: { range: [0, 150], unit: "mg/dL", category: "Lipid Profile", label: "Triglycerides" },
    vldl: { range: [5, 40], unit: "mg/dL", category: "Lipid Profile", label: "VLDL" },

    // Thyroid
    tsh: { range: [0.4, 4.0], unit: "mIU/L", category: "Thyroid", label: "TSH" },
    t3: { range: [100, 200], unit: "ng/dL", category: "Thyroid", label: "T3" },
    t4: { range: [5, 12], unit: "µg/dL", category: "Thyroid", label: "T4" },

    // Electrolytes
    sodium: { range: [135, 145], unit: "mmol/L", category: "Electrolytes", label: "Sodium" },
    potassium: { range: [3.5, 5.0], unit: "mmol/L", category: "Electrolytes", label: "Potassium" },
    calcium: { range: [8.6, 10.2], unit: "mg/dL", category: "Electrolytes", label: "Calcium" },
    chloride: { range: [96, 106], unit: "mmol/L", category: "Electrolytes", label: "Chloride" },
    magnesium: { range: [1.7, 2.2], unit: "mg/dL", category: "Electrolytes", label: "Magnesium" },

    // Vitamins
    vitamin_b12: { range: [200, 900], unit: "pg/mL", category: "Vitamins", label: "Vitamin B12" },
    vitamin_d: { range: [20, 50], unit: "ng/mL", category: "Vitamins", label: "Vitamin D" },

    // Iron Studies
    ferritin: { range: [30, 400], unit: "ng/mL", category: "Iron Studies", label: "Ferritin" },
    iron: { range: [60, 170], unit: "µg/dL", category: "Iron Studies", label: "Iron" },
  };

  // API Route for Analysis
  app.post("/api/analyze", (req, res) => {
    const data = req.body;
    const results = [];
    let abnormalCount = 0;

    Object.keys(REFERENCE_RANGES).forEach(key => {
      const value = parseFloat(data[key]);
      if (isNaN(value)) return;

      const config = (REFERENCE_RANGES as any)[key];
      const range = config.range;
      let status = "Normal";
      
      const lowerLimit = range[0];
      const upperLimit = range[1];
      const margin = (upperLimit - lowerLimit) * 0.05; // 5% margin for borderline

      if (value < lowerLimit) {
        status = "Low";
      } else if (value > upperLimit) {
        status = "High";
      } else {
        const nearUpper = value >= upperLimit - margin;
        const nearLower = lowerLimit > 0 && value <= lowerLimit + margin;
        if (nearUpper || nearLower) {
          status = "Borderline";
        }
      }
      if (status !== "Normal" && status !== "Borderline") {
        abnormalCount++;
      } else if (status === "Borderline") {
        abnormalCount += 0.5;
      }
      
      results.push({
        parameter: config.label,
        category: config.category,
        value,
        min: lowerLimit,
        max: upperLimit,
        range: `${lowerLimit} - ${upperLimit}`,
        status,
        unit: config.unit
      });
    });

    res.json({
      results,
      summary: `${abnormalCount} parameter${abnormalCount !== 1 ? 's are' : ' is'} outside the normal range`,
      gender: data.gender || "male"
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
