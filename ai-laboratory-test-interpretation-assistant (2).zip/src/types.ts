export interface LabResult {
  parameter: string;
  category: string;
  value: number;
  min: number;
  max: number;
  range: string;
  status: "Normal" | "High" | "Low" | "Borderline";
  unit: string;
}

export interface AnalysisResponse {
  results: LabResult[];
  summary: string;
  gender: string;
  name?: string;
  age?: number;
}

export interface ComparisonResult {
  parameter: string;
  previous: number;
  previousStatus: string;
  current: number;
  currentStatus: string;
  difference: number;
  trend: "Increased" | "Decreased" | "Same" | "Improved" | "No Change";
  foods: string[];
}

export interface LabValues {
  gender: "male" | "female";
  [key: string]: number | string | undefined;
}
