import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  Upload, 
  FileText, 
  ShieldCheck, 
  Zap, 
  ChevronRight, 
  ArrowLeft, 
  AlertCircle, 
  CheckCircle2, 
  Info,
  Menu,
  X,
  Moon,
  Sun,
  Download,
  Stethoscope,
  Microscope,
  HeartPulse,
  HelpCircle,
  MessageSquare,
  Mail,
  TrendingUp,
  TrendingDown,
  Minus,
  Users,
  Scale
} from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import axios from 'axios';
import Tesseract from 'tesseract.js';
import { GoogleGenAI, Type } from "@google/genai";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ReferenceArea, ReferenceLine } from 'recharts';
import { cn } from './lib/utils';
import ReactMarkdown from 'react-markdown';
import { LabResult, AnalysisResponse, LabValues, ComparisonResult } from './types';

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

// --- Components ---

const RangeIndicator = ({ value, min, max, status, darkMode }: { 
  value: number, 
  min: number, 
  max: number, 
  status: string,
  darkMode: boolean 
}) => {
  // Calculate position percentage
  // We want to show a range that includes min, max, and value.
  const rangePadding = (max - min) * 0.2 || 1;
  const displayMin = Math.min(min - rangePadding, value);
  const displayMax = Math.max(max + rangePadding, value);
  const totalRange = displayMax - displayMin || 1;
  
  const valuePos = ((value - displayMin) / totalRange) * 100;
  const minPos = ((min - displayMin) / totalRange) * 100;
  const maxPos = ((max - displayMin) / totalRange) * 100;
  const rangeWidth = maxPos - minPos;

  const getStatusColor = () => {
    if (status === 'Normal') return 'bg-teal-500';
    if (status === 'Borderline') return 'bg-amber-500';
    return 'bg-red-500';
  };

  return (
    <div className="w-full space-y-1.5">
      <div className="relative h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
        {/* Normal Range Zone */}
        <div 
          className="absolute h-full bg-teal-500/20 dark:bg-teal-500/10 border-x border-teal-500/30"
          style={{ left: `${minPos}%`, width: `${rangeWidth}%` }}
        />
        {/* Patient Value Marker */}
        <motion.div 
          initial={{ left: 0, opacity: 0 }}
          animate={{ left: `${valuePos}%`, opacity: 1 }}
          transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
          className={cn("absolute top-0 w-1 h-full z-10 shadow-sm", getStatusColor())}
        />
      </div>
      <div className="flex justify-between text-[9px] font-bold text-slate-400 uppercase tracking-tighter">
        <span>{displayMin.toFixed(1)}</span>
        <div className="flex gap-3">
          <span className="text-teal-600/70">Min: {min}</span>
          <span className="text-teal-600/70">Max: {max}</span>
        </div>
        <span>{displayMax.toFixed(1)}</span>
      </div>
    </div>
  );
};

const ParameterBarChart = ({ data, darkMode }: { data: LabResult[], darkMode: boolean }) => {
  const chartData = data.slice(0, 10).map(r => {
    const range = r.max - r.min || 1;
    const normalizedValue = ((r.value - r.min) / range) * 100;
    return {
      name: r.parameter,
      value: normalizedValue,
      originalValue: r.value,
      unit: r.unit,
      status: r.status,
      min: 0,
      max: 100
    };
  });

  return (
    <div className="h-80 w-full mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={darkMode ? "#334155" : "#e2e8f0"} />
          <XAxis 
            dataKey="name" 
            angle={-45} 
            textAnchor="end" 
            interval={0} 
            tick={{ fontSize: 10, fill: darkMode ? "#94a3b8" : "#64748b" }} 
          />
          <YAxis hide />
          <Tooltip 
            cursor={{ fill: darkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.02)' }}
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const item = payload[0].payload;
                return (
                  <div className="bg-slate-900 text-white p-3 rounded-xl shadow-2xl border border-slate-800 text-xs">
                    <p className="font-bold mb-1">{item.name}</p>
                    <p className="text-blue-300">Value: {item.originalValue} {item.unit}</p>
                    <p className={cn(
                      "font-bold",
                      item.status === 'Normal' ? "text-teal-400" : 
                      item.status === 'Borderline' ? "text-amber-400" : "text-red-400"
                    )}>
                      Status: {item.status}
                    </p>
                  </div>
                );
              }
              return null;
            }}
          />
          <ReferenceArea y1={0} y2={100} fill="#38B2AC" fillOpacity={0.1} />
          <ReferenceLine y={0} stroke="#38B2AC" strokeDasharray="3 3" strokeOpacity={0.5} />
          <ReferenceLine y={100} stroke="#38B2AC" strokeDasharray="3 3" strokeOpacity={0.5} />
          
          <Bar dataKey="value" radius={[4, 4, 0, 0]}>
            {chartData.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={
                  entry.status === 'Normal' ? '#38B2AC' : 
                  entry.status === 'Borderline' ? '#F59E0B' : '#EF4444'
                } 
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <div className="flex justify-center gap-4 mt-2">
        <div className="flex items-center gap-1 text-[10px] font-bold text-teal-600/50 uppercase tracking-widest">
          <div className="w-3 h-1 bg-teal-500/20" /> Normal Range (0-100%)
        </div>
      </div>
    </div>
  );
};

const Navbar = ({ onNavigate, currentPath, darkMode, toggleDarkMode, onOpenHelp }: { 
  onNavigate: (path: string) => void, 
  currentPath: string,
  darkMode: boolean,
  toggleDarkMode: () => void,
  onOpenHelp: () => void
}) => {
  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b",
      darkMode ? "bg-slate-900/80 border-slate-800" : "bg-white/80 border-slate-200",
      "backdrop-blur-md"
    )}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div 
            className="flex items-center gap-2 cursor-pointer group"
            onClick={() => onNavigate('landing')}
          >
            <div className="bg-medical-blue p-2 rounded-lg group-hover:scale-110 transition-transform">
              <Activity className="text-white w-6 h-6" />
            </div>
            <span className={cn(
              "font-bold text-xl tracking-tight hidden sm:block",
              darkMode ? "text-white" : "text-medical-blue"
            )}>
              LabAI Assistant
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            <button 
              onClick={() => onNavigate('comparison')}
              className={cn(
                "p-2 rounded-full transition-colors group relative",
                darkMode ? "hover:bg-slate-800 text-slate-400" : "hover:bg-slate-100 text-slate-600",
                currentPath === 'comparison' && "bg-blue-50 text-medical-blue dark:bg-blue-900/30"
              )}
              title="Compare Reports"
            >
              <Scale size={20} className="group-hover:scale-110 transition-transform" />
              <span className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                Compare Reports
              </span>
            </button>
            <button 
              onClick={onOpenHelp}
              className={cn(
                "p-2 rounded-full transition-colors group relative",
                darkMode ? "hover:bg-slate-800 text-slate-400" : "hover:bg-slate-100 text-slate-600"
              )}
              title="Help & Support"
            >
              <HelpCircle size={20} className="group-hover:rotate-12 transition-transform" />
              <span className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                Help & Support
              </span>
            </button>
            <button 
              onClick={toggleDarkMode}
              className={cn(
                "p-2 rounded-full transition-colors group relative",
                darkMode ? "hover:bg-slate-800 text-yellow-400" : "hover:bg-slate-100 text-slate-600"
              )}
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
              <span className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                Toggle {darkMode ? 'Light' : 'Dark'} Mode
              </span>
            </button>
            <button 
              onClick={() => onNavigate('analysis')}
              className="bg-medical-teal hover:bg-teal-600 text-white px-4 sm:px-5 py-2 rounded-full font-medium transition-all shadow-lg shadow-teal-500/20 active:scale-95 text-sm sm:text-base group relative"
            >
              Analyze Now
              <span className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50">
                Start your lab report analysis
              </span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

const HelpModal = ({ isOpen, onClose, darkMode }: { isOpen: boolean, onClose: () => void, darkMode: boolean }) => {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const faqs = [
    {
      q: "What type of reports can I upload?",
      a: "You can upload blood test reports, CBC reports, thyroid reports, and other laboratory reports in image or PDF format."
    },
    {
      q: "What image formats are supported?",
      a: "We support JPG, PNG, JPEG, and PDF files."
    },
    {
      q: "How does the AI read my report?",
      a: "The system uses Optical Character Recognition (OCR) to scan the report and extract medical values automatically using advanced AI models."
    },
    {
      q: "Is my data safe?",
      a: "Yes, all uploaded reports are processed securely and are not stored permanently. We prioritize your privacy."
    },
    {
      q: "What if the AI reads the values incorrectly?",
      a: "The user can manually edit the extracted values in the 'Manual Input' section before submitting the report for final analysis."
    }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className={cn(
              "relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl shadow-2xl",
              darkMode ? "bg-slate-900 text-white border border-slate-800" : "bg-white text-slate-900"
            )}
          >
            <div className="sticky top-0 z-10 flex items-center justify-between p-6 border-b border-slate-100 dark:border-slate-800 bg-inherit">
              <div className="flex items-center gap-3">
                <div className="bg-medical-blue p-2 rounded-xl">
                  <HelpCircle className="text-white" size={24} />
                </div>
                <h2 className="text-2xl font-bold">Help & Support</h2>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="p-6 space-y-8">
              {/* How to Use */}
              <section>
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Info size={20} className="text-medical-teal" />
                  How to Use the Website
                </h3>
                <div className="grid gap-4">
                  {[
                    "Upload the photocopy or image of your laboratory report.",
                    "The AI system will scan the report using OCR technology.",
                    "The extracted values will automatically appear in the manual input section.",
                    "The system compares the values with standard medical reference ranges.",
                    "The system analyzes and shows whether values are Normal, High, or Low.",
                    "A final summary will display if the report is in the Safe Zone or Needs Medical Attention."
                  ].map((step, i) => (
                    <div key={i} className="flex gap-4 items-start">
                      <div className="w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900/30 text-medical-blue dark:text-blue-400 flex items-center justify-center text-xs font-bold shrink-0 mt-1">
                        {i + 1}
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400">{step}</p>
                    </div>
                  ))}
                </div>
              </section>

              {/* FAQ */}
              <section>
                <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <MessageSquare size={20} className="text-medical-teal" />
                  Frequently Asked Questions
                </h3>
                <div className="space-y-2">
                  {faqs.map((faq, i) => (
                    <div key={i} className="border border-slate-100 dark:border-slate-800 rounded-2xl overflow-hidden">
                      <button
                        onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                        className="w-full flex items-center justify-between p-4 text-left hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                      >
                        <span className="font-bold text-sm">{faq.q}</span>
                        <ChevronRight className={cn("transition-transform", activeFaq === i ? "rotate-90" : "")} size={18} />
                      </button>
                      <AnimatePresence>
                        {activeFaq === i && (
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: "auto" }}
                            exit={{ height: 0 }}
                            className="overflow-hidden"
                          >
                            <div className="p-4 pt-0 text-sm text-slate-500 dark:text-slate-400 border-t border-slate-50 dark:border-slate-800">
                              {faq.a}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}
                </div>
              </section>

              {/* Contact Support */}
              <section className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-3xl border border-slate-100 dark:border-slate-800">
                <h3 className="text-lg font-bold mb-6">Contact Support</h3>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white dark:bg-slate-800 rounded-xl flex items-center justify-center shadow-sm">
                        <Mail className="text-medical-blue" size={20} />
                      </div>
                      <div>
                        <p className="text-xs text-slate-400 font-bold uppercase">Email Support</p>
                        <p className="text-sm font-bold">support@labai.com</p>
                      </div>
                    </div>
                    <button className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 py-3 rounded-xl text-sm font-bold hover:bg-slate-50 dark:hover:bg-slate-700 transition-all">
                      Report an Issue
                    </button>
                  </div>
                  <form className="space-y-3" onSubmit={(e) => e.preventDefault()}>
                    <p className="text-xs text-slate-400 font-bold uppercase">Feedback Form</p>
                    <textarea 
                      placeholder="How can we improve?"
                      className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                      rows={3}
                    />
                    <button className="w-full bg-medical-blue text-white py-3 rounded-xl text-sm font-bold shadow-lg shadow-blue-900/10">
                      Send Feedback
                    </button>
                  </form>
                </div>
              </section>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const ChatAssistant = ({ darkMode }: { darkMode: boolean }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: "Hello! I'm your LabAI Assistant. How can I help you today?" }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const prompt = `
        You are a helpful AI assistant for the LabAI Assistant website.
        Website Purpose: Interpreting medical laboratory reports using AI.
        
        Common Questions & Answers:
        - How to upload a report? Answer: Click 'Analyze Now', then use the 'Upload Report' tab to drag and drop your image or PDF.
        - What does high hemoglobin mean? Answer: High hemoglobin (polycythemia) can be caused by dehydration, smoking, living at high altitudes, or certain medical conditions. Always consult a doctor for a full diagnosis.
        - Why is my report marked abnormal? Answer: A report is marked abnormal if one or more values fall outside the standard medical reference ranges for your age and gender.
        
        User Question: ${userMsg}
        
        Provide a helpful, concise response. If it's a medical question, always include a disclaimer that you are an AI and not a doctor.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ parts: [{ text: prompt }] }]
      });

      setMessages(prev => [...prev, { role: 'ai', text: response.text || "I'm sorry, I couldn't process that." }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'ai', text: "I'm having trouble connecting. Please try again later." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[90]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20, transformOrigin: 'bottom right' }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className={cn(
              "absolute bottom-20 right-0 w-80 sm:w-96 h-[500px] rounded-3xl shadow-2xl flex flex-col overflow-hidden border",
              darkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
            )}
          >
            <div className="p-4 bg-medical-blue text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                  <Activity size={18} />
                </div>
                <div>
                  <h4 className="font-bold text-sm">LabAI Support</h4>
                  <p className="text-[10px] text-blue-200">Online and ready to help</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button 
                  onClick={() => setMessages([{ role: 'ai', text: "Hello! I'm your LabAI Assistant. How can I help you today?" }])}
                  className="p-1 hover:bg-white/10 rounded-full transition-colors"
                  title="Clear Chat"
                >
                  <X size={16} />
                </button>
                <button onClick={() => setIsOpen(false)} className="p-1 hover:bg-white/10 rounded-full transition-colors">
                  <X size={20} />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((msg, i) => (
                <div key={i} className={cn("flex", msg.role === 'user' ? "justify-end" : "justify-start")}>
                  <div className={cn(
                    "max-w-[80%] p-3 rounded-2xl text-sm",
                    msg.role === 'user' 
                      ? "bg-medical-blue text-white rounded-tr-none" 
                      : darkMode ? "bg-slate-800 text-slate-200 rounded-tl-none" : "bg-slate-100 text-slate-700 rounded-tl-none"
                  )}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className={cn("p-3 rounded-2xl rounded-tl-none flex gap-1", darkMode ? "bg-slate-800" : "bg-slate-100")}>
                    <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1 }} className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                    <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                    <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-100 dark:border-slate-800">
              <div className="flex gap-2">
                <input 
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask a question..."
                  className="flex-1 bg-slate-50 dark:bg-slate-800 border-none rounded-xl px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                />
                <button 
                  onClick={handleSend}
                  className="bg-medical-blue text-white p-2 rounded-xl hover:bg-blue-900 transition-colors"
                >
                  <ChevronRight size={20} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-medical-blue text-white rounded-full shadow-2xl flex items-center justify-center relative group"
      >
        <MessageSquare size={24} />
        <span className="absolute right-full mr-4 bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
          Need help? Chat with us
        </span>
      </motion.button>
    </div>
  );
};

const QuickCheck = ({ darkMode }: { darkMode: boolean }) => {
  const [value, setValue] = useState('');
  const [result, setResult] = useState<{ status: string, foods: string, tip: string, color: string } | null>(null);

  const analyze = () => {
    const hb = parseFloat(value);
    if (isNaN(hb)) return;

    if (hb < 12) {
      setResult({
        status: "LOW - Possible Iron Deficiency",
        foods: "Spinach, Lentils, Eggs, Beetroot, Almonds",
        tip: "Your hemoglobin is below the typical range. Focus on iron-rich foods and consider consulting a doctor.",
        color: "red"
      });
    } else if (hb >= 12 && hb <= 17) {
      setResult({
        status: "NORMAL",
        foods: "Maintain a balanced diet with proteins and leafy greens.",
        tip: "Great! Your hemoglobin levels are within the healthy range.",
        color: "teal"
      });
    } else {
      setResult({
        status: "HIGH",
        foods: "Focus on hydration and consult a doctor for a full evaluation.",
        tip: "Elevated hemoglobin can be caused by various factors. A medical consultation is recommended.",
        color: "amber"
      });
    }
  };

  return (
    <div className={cn(
      "p-8 rounded-3xl shadow-xl border transition-all",
      darkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
    )}>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center text-medical-blue">
          <Activity size={20} />
        </div>
        <h3 className="text-xl font-bold text-slate-800 dark:text-white">Quick Hemoglobin Check</h3>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <input 
          type="number" 
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Enter Hb value (g/dL)"
          className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent outline-none focus:ring-2 focus:ring-medical-blue dark:text-white"
        />
        <button 
          onClick={analyze}
          className="bg-medical-blue text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-900 transition-all active:scale-95 shadow-lg shadow-blue-900/10"
        >
          Analyze
        </button>
      </div>

      <AnimatePresence mode="wait">
        {result && (
          <motion.div
            key={result.status}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={cn(
              "p-6 rounded-2xl border",
              result.color === 'red' ? "bg-red-50 dark:bg-red-900/10 border-red-100 dark:border-red-900/20 text-red-900 dark:text-red-400" :
              result.color === 'teal' ? "bg-teal-50 dark:bg-teal-900/10 border-teal-100 dark:border-teal-900/20 text-teal-900 dark:text-teal-400" :
              "bg-amber-50 dark:bg-amber-900/10 border-amber-100 dark:border-amber-900/20 text-amber-900 dark:text-amber-400"
            )}
          >
            <div className="flex items-center gap-2 mb-2">
              {result.color === 'teal' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
              <h4 className="font-bold text-lg">Hemoglobin Status: {result.status}</h4>
            </div>
            <p className="text-sm mb-3">
              <span className="font-bold text-medical-teal dark:text-teal-500">Recommended Foods:</span> {result.foods}
            </p>
            <div className="flex items-start gap-2 p-3 bg-white/50 dark:bg-black/20 rounded-xl">
              <Zap size={14} className="mt-0.5 shrink-0" />
              <p className="text-xs italic"><strong>AI Tip:</strong> {result.tip}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const REFERENCE_RANGES: Record<string, { min: number, max: number, unit: string }> = {
  "Hemoglobin": { min: 12, max: 16, unit: "g/dL" },
  "WBC": { min: 4000, max: 11000, unit: "/µL" },
  "Platelets": { min: 150000, max: 450000, unit: "/µL" },
  "Glucose": { min: 70, max: 110, unit: "mg/dL" }
};

const ComparisonPage = ({ onBack, darkMode }: { onBack: () => void, darkMode: boolean }) => {
  const [prevPatient, setPrevPatient] = useState({ name: '', age: '' });
  const [currPatient, setCurrPatient] = useState({ name: '', age: '' });
  const [prevReport, setPrevReport] = useState<Record<string, string>>({ hemoglobin: '', glucose: '', wbc: '', platelets: '' });
  const [currReport, setCurrReport] = useState<Record<string, string>>({ hemoglobin: '', glucose: '', wbc: '', platelets: '' });
  const [results, setResults] = useState<ComparisonResult[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isVerified, setIsVerified] = useState(false);
  const [isScanning, setIsScanning] = useState(false);

  const foodDataset: Record<string, string[]> = {
    "hemoglobin_low": ["Spinach", "Lentils", "Eggs", "Beetroot", "Almonds"],
    "glucose_high": ["Oats", "Broccoli", "Spinach", "Almonds", "Beans"],
    "wbc_low": ["Garlic", "Ginger", "Yogurt", "Spinach", "Citrus Fruits"],
    "platelets_low": ["Papaya Leaf", "Pumpkin", "Spinach", "Beetroot", "Carrots"]
  };

  const parseOCRText = (text: string) => {
    const nameMatch = text.match(/Name:\s*([a-zA-Z\s]+)/i);
    const ageMatch = text.match(/Age:\s*(\d+)/i);
    const hbMatch = text.match(/Hemoglobin:\s*(\d+(\.\d+)?)/i);
    const glucoseMatch = text.match(/Glucose:\s*(\d+(\.\d+)?)/i);
    const wbcMatch = text.match(/WBC:\s*(\d+(\.\d+)?)/i);
    const plateletsMatch = text.match(/Platelets:\s*(\d+(\.\d+)?)/i);
    
    return {
      name: nameMatch ? nameMatch[1].trim() : "Unknown",
      age: ageMatch ? ageMatch[1] : "",
      hemoglobin: hbMatch ? hbMatch[1] : "",
      glucose: glucoseMatch ? glucoseMatch[1] : "",
      wbc: wbcMatch ? wbcMatch[1] : "",
      platelets: plateletsMatch ? plateletsMatch[1] : ""
    };
  };

  const handleFileUpload = async (file: File, type: 'prev' | 'curr') => {
    setIsScanning(true);
    setError(null);
    try {
      const { data: { text } } = await Tesseract.recognize(file, 'eng');
      const parsed = parseOCRText(text);
      
      if (type === 'prev') {
        setPrevPatient({ name: parsed.name, age: parsed.age });
        setPrevReport({ 
          hemoglobin: parsed.hemoglobin, 
          glucose: parsed.glucose,
          wbc: parsed.wbc,
          platelets: parsed.platelets
        });
      } else {
        setCurrPatient({ name: parsed.name, age: parsed.age });
        setCurrReport({ 
          hemoglobin: parsed.hemoglobin, 
          glucose: parsed.glucose,
          wbc: parsed.wbc,
          platelets: parsed.platelets
        });
      }
    } catch (err) {
      setError("Failed to scan the report. Please try manual entry.");
    } finally {
      setIsScanning(false);
    }
  };

  const checkAbnormal = (testName: string, value: number) => {
    const range = REFERENCE_RANGES[testName];
    if (range) {
      if (value < range.min) return "Low";
      if (value > range.max) return "High";
      return "Normal";
    }
    return "Unknown";
  };

  const handleCompare = () => {
    if (!prevPatient.name || !prevPatient.age || !currPatient.name || !currPatient.age) {
      setError("Please enter patient information for both reports.");
      return;
    }

    if (prevPatient.name.toLowerCase() !== currPatient.name.toLowerCase() || prevPatient.age !== currPatient.age) {
      setError("Reports belong to different patients ❌");
      setIsVerified(false);
      setResults(null);
      return;
    }

    setError(null);
    setIsVerified(true);

    const comparisonResults: ComparisonResult[] = Object.keys(REFERENCE_RANGES).map(paramName => {
      const key = paramName.toLowerCase();
      const prev = parseFloat(prevReport[key]) || 0;
      const curr = parseFloat(currReport[key]) || 0;
      const diff = curr - prev;
      
      let trend: "Increased" | "Decreased" | "Same" = "Same";
      if (diff > 0) trend = "Increased";
      else if (diff < 0) trend = "Decreased";

      const previousStatus = checkAbnormal(paramName, prev);
      const currentStatus = checkAbnormal(paramName, curr);

      let foods: string[] = ["Balanced Diet"];
      if (currentStatus === "Low") {
        foods = foodDataset[`${key}_low`] || ["Nutrient-rich diet"];
      } else if (currentStatus === "High") {
        foods = foodDataset[`${key}_high`] || ["Consult specialist"];
      }

      return {
        parameter: paramName,
        previous: prev,
        previousStatus,
        current: curr,
        currentStatus,
        difference: diff,
        trend,
        foods
      };
    });

    setResults(comparisonResults);
  };

  return (
    <div className="pt-24 pb-20 max-w-5xl mx-auto px-4">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-slate-500 hover:text-medical-blue transition-colors mb-8 group"
      >
        <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
        Back to Home
      </button>

      <div className={cn(
        "rounded-3xl shadow-xl overflow-hidden border",
        darkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-100"
      )}>
        <div className="p-8 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-4 mb-8">
            <div className="bg-medical-blue p-3 rounded-2xl">
              <Scale className="text-white" size={24} />
            </div>
            <div>
              <h2 className="text-2xl font-bold dark:text-white">Report Comparison Module</h2>
              <p className="text-sm text-slate-500">Compare previous and current laboratory results to track health trends.</p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Previous Report Section */}
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500">
                    <FileText size={18} />
                  </div>
                  <h3 className="font-bold text-slate-700 dark:text-slate-300">Previous Report</h3>
                </div>
                <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 px-3 py-1 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-400 transition-all flex items-center gap-1">
                  <Upload size={14} />
                  Scan Image
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*"
                    onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'prev')}
                  />
                </label>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Patient Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. John Doe"
                      value={prevPatient.name}
                      onChange={(e) => setPrevPatient({ ...prevPatient, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Age</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 35"
                      value={prevPatient.age}
                      onChange={(e) => setPrevPatient({ ...prevPatient, age: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Hemoglobin (g/dL)</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 13.5"
                      value={prevReport.hemoglobin}
                      onChange={(e) => setPrevReport({ ...prevReport, hemoglobin: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Glucose (mg/dL)</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 95"
                      value={prevReport.glucose}
                      onChange={(e) => setPrevReport({ ...prevReport, glucose: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">WBC (/µL)</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 7000"
                      value={prevReport.wbc}
                      onChange={(e) => setPrevReport({ ...prevReport, wbc: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Platelets (/µL)</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 250000"
                      value={prevReport.platelets}
                      onChange={(e) => setPrevReport({ ...prevReport, platelets: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Current Report Section */}
            <div className="space-y-6">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-medical-blue/10 flex items-center justify-center text-medical-blue">
                    <Zap size={18} />
                  </div>
                  <h3 className="font-bold text-slate-700 dark:text-slate-300">Current Report</h3>
                </div>
                <label className="cursor-pointer bg-blue-50 hover:bg-blue-100 dark:bg-blue-900/20 dark:hover:bg-blue-900/30 px-3 py-1 rounded-lg text-xs font-bold text-medical-blue transition-all flex items-center gap-1">
                  <Upload size={14} />
                  Scan Image
                  <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*"
                    onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'curr')}
                  />
                </label>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Patient Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. John Doe"
                      value={currPatient.name}
                      onChange={(e) => setCurrPatient({ ...currPatient, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Age</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 35"
                      value={currPatient.age}
                      onChange={(e) => setCurrPatient({ ...currPatient, age: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Hemoglobin (g/dL)</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 14.2"
                      value={currReport.hemoglobin}
                      onChange={(e) => setCurrReport({ ...currReport, hemoglobin: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Glucose (mg/dL)</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 105"
                      value={currReport.glucose}
                      onChange={(e) => setCurrReport({ ...currReport, glucose: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">WBC (/µL)</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 8000"
                      value={currReport.wbc}
                      onChange={(e) => setCurrReport({ ...currReport, wbc: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Platelets (/µL)</label>
                    <input 
                      type="number" 
                      placeholder="e.g. 260000"
                      value={currReport.platelets}
                      onChange={(e) => setCurrReport({ ...currReport, platelets: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-transparent dark:text-white outline-none focus:ring-2 focus:ring-medical-blue transition-all"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="mt-8 p-4 bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/20 rounded-2xl flex items-center gap-3 text-red-700 dark:text-red-400">
              <AlertCircle size={20} />
              <p className="text-sm font-medium">{error}</p>
            </div>
          )}

          <button 
            onClick={handleCompare}
            disabled={isScanning}
            className={cn(
              "w-full mt-10 bg-medical-blue hover:bg-blue-900 text-white py-4 rounded-2xl font-bold text-lg transition-all shadow-xl shadow-blue-900/20 active:scale-[0.98] flex items-center justify-center gap-2",
              isScanning && "opacity-70 cursor-not-allowed"
            )}
          >
            {isScanning ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Scanning Reports...
              </>
            ) : (
              <>
                <Scale size={20} />
                Compare Reports
              </>
            )}
          </button>
        </div>

        <div className="p-8 bg-slate-50 dark:bg-slate-800/30">
          <AnimatePresence mode="wait">
            {results && isVerified ? (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-8"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-teal-100 dark:bg-teal-900/30 flex items-center justify-center text-teal-600">
                      <CheckCircle2 size={24} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold dark:text-white">Patient Verified ✅</h3>
                      <p className="text-sm text-slate-500">Reports successfully matched for {currPatient.name}, Age {currPatient.age}</p>
                    </div>
                  </div>
                  <div className="px-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-sm">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-1">Comparison Date</span>
                    <span className="text-sm font-bold dark:text-white">{new Date().toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-8">
                  {results.map((res, i) => (
                    <div 
                      key={i}
                      className={cn(
                        "p-6 rounded-3xl border transition-all",
                        res.trend === 'Increased' ? "bg-blue-50/50 dark:bg-blue-900/10 border-blue-100 dark:border-blue-900/20" :
                        res.trend === 'Decreased' ? "bg-amber-50/50 dark:bg-amber-900/10 border-amber-100 dark:border-amber-900/20" :
                        "bg-slate-100/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700"
                      )}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h4 className="font-bold text-lg dark:text-white">{res.parameter}</h4>
                          <div className="flex flex-wrap gap-2 mt-1">
                            <span className={cn(
                              "text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded",
                              res.previousStatus === 'Normal' ? "bg-teal-500/10 text-teal-600" : "bg-red-500/10 text-red-600"
                            )}>
                              R1: {res.previousStatus}
                            </span>
                            <span className={cn(
                              "text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded",
                              res.currentStatus === 'Normal' ? "bg-teal-500/10 text-teal-600" : "bg-red-500/10 text-red-600"
                            )}>
                              R2: {res.currentStatus}
                            </span>
                          </div>
                        </div>
                        <div className={cn(
                          "flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold",
                          res.trend === 'Increased' ? "bg-blue-500 text-white" :
                          res.trend === 'Decreased' ? "bg-amber-500 text-white" :
                          "bg-slate-400 text-white"
                        )}>
                          {res.trend === 'Increased' ? <TrendingUp size={14} /> : 
                           res.trend === 'Decreased' ? <TrendingDown size={14} /> : <Minus size={14} />}
                          {res.trend}
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                          <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Previous</p>
                          <p className="text-lg font-bold dark:text-white">{res.previous}</p>
                        </div>
                        <div className="p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                          <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Current</p>
                          <p className="text-lg font-bold dark:text-white">{res.current}</p>
                        </div>
                      </div>

                      <div className="flex justify-between items-center mb-4">
                        <span className="text-xs text-slate-500">Difference</span>
                        <span className={cn(
                          "font-bold",
                          res.difference > 0 ? "text-teal-600" : res.difference < 0 ? "text-red-600" : "text-slate-600"
                        )}>
                          {res.difference > 0 ? '+' : ''}{res.difference}
                        </span>
                      </div>

                      <div className="p-4 bg-white/50 dark:bg-black/20 rounded-2xl">
                        <p className="text-xs font-bold text-medical-teal mb-2 flex items-center gap-1">
                          <Zap size={12} />
                          Recommended Foods
                        </p>
                        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                          {res.foods.join(", ")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            ) : (
              <div className="py-12 text-center">
                <div className="w-16 h-16 bg-slate-200 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                  <Scale size={32} />
                </div>
                <h3 className="text-lg font-bold text-slate-400">Enter values to see comparison</h3>
                <p className="text-sm text-slate-400">Trends and recommendations will appear here.</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

const LandingPage = ({ onStart, onNavigate, darkMode }: { onStart: () => void, onNavigate: (path: string) => void, darkMode: boolean }) => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-400 text-sm font-semibold mb-6">
                <Zap size={14} />
                <span>AI-Powered Medical Insights</span>
              </div>
              <h1 className="text-5xl lg:text-6xl font-extrabold text-medical-blue dark:text-blue-400 leading-tight mb-6">
                Understand Your Lab Reports <span className="text-medical-teal">Instantly</span>
              </h1>
              <p className="text-lg text-slate-600 dark:text-slate-400 mb-8 max-w-lg">
                Upload your medical laboratory results and let our advanced AI provide simplified, easy-to-understand explanations of your health data.
              </p>
              <div className="flex flex-wrap gap-4 mb-12">
                <button 
                  onClick={onStart}
                  className="bg-medical-blue hover:bg-blue-900 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all flex items-center gap-2 shadow-xl shadow-blue-900/20 group"
                >
                  <div className="bg-white/20 p-2 rounded-lg">
                    <Microscope size={20} />
                  </div>
                  1️⃣ Report Scanning Module
                  <ChevronRight className="group-hover:translate-x-1 transition-transform" />
                </button>
                <button 
                  onClick={() => onNavigate('comparison')}
                  className="bg-white hover:bg-slate-50 text-medical-blue border-2 border-medical-blue px-8 py-4 rounded-xl font-bold text-lg transition-all flex items-center gap-2 shadow-xl shadow-blue-900/5 group"
                >
                  <div className="bg-medical-blue/10 p-2 rounded-lg">
                    <Scale size={20} />
                  </div>
                  2️⃣ Comparison Module
                  <ChevronRight className="group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              {/* Quick Check Widget Integrated into Landing */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="max-w-md"
              >
                <QuickCheck darkMode={darkMode} />
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="relative z-10 bg-white p-6 rounded-3xl shadow-2xl border border-slate-100">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-medical-blue">
                      <Microscope />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-800">Blood Analysis</h3>
                      <p className="text-xs text-slate-500">Processing complete</p>
                    </div>
                  </div>
                  <div className="bg-teal-100 text-teal-700 px-3 py-1 rounded-full text-xs font-bold">
                    98% Accuracy
                  </div>
                </div>
                
                <div className="space-y-4">
                  {[
                    { label: 'Hemoglobin', value: 12.5, status: 'Normal', color: 'bg-teal-500' },
                    { label: 'WBC Count', value: 11200, status: 'High', color: 'bg-red-500' },
                    { label: 'Glucose', value: 95, status: 'Normal', color: 'bg-teal-500' }
                  ].map((item, i) => (
                    <div key={i} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium text-slate-700">{item.label}</span>
                        <span className={cn("font-bold", item.status === 'High' ? 'text-red-500' : 'text-teal-600')}>{item.status}</span>
                      </div>
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: item.status === 'High' ? '90%' : '65%' }}
                          transition={{ duration: 1, delay: 0.5 + (i * 0.2) }}
                          className={cn("h-full rounded-full", item.color)}
                        />
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-4 bg-blue-50 rounded-2xl border border-blue-100">
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-sm shrink-0">
                      <Zap size={16} className="text-blue-600" />
                    </div>
                    <p className="text-xs text-blue-800 leading-relaxed">
                      "Your WBC count is slightly elevated. This often indicates your body is fighting a minor infection or inflammation."
                    </p>
                  </div>
                </div>
              </div>

              {/* Decorative elements */}
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-teal-200/30 rounded-full blur-3xl" />
              <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-blue-200/30 rounded-full blur-3xl" />
              
              <motion.div 
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-6 -left-6 bg-white p-3 rounded-xl shadow-lg border border-slate-100 z-20"
              >
                <ShieldCheck className="text-teal-500" />
              </motion.div>
              
              <motion.div 
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -bottom-6 -right-6 bg-white p-3 rounded-xl shadow-lg border border-slate-100 z-20"
              >
                <HeartPulse className="text-red-500" />
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-medical-blue py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { label: 'Reports Analyzed', value: '500k+' },
              { label: 'Accuracy Rate', value: '99.2%' },
              { label: 'Active Users', value: '120k' },
              { label: 'Medical Experts', value: '50+' }
            ].map((stat, i) => (
              <div key={i}>
                <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-blue-200 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
          <h2 className="text-3xl font-bold text-medical-blue mb-4">Why Choose LabAI Assistant?</h2>
          <p className="text-slate-500 max-w-2xl mx-auto">Our platform combines medical expertise with cutting-edge AI to make healthcare information accessible to everyone.</p>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-3 gap-8">
          {[
            { 
              icon: <Activity className="text-teal-500" />, 
              title: 'Lab Test Analysis', 
              desc: 'Detailed breakdown of common blood tests and metabolic panels.' 
            },
            { 
              icon: <AlertCircle className="text-orange-500" />, 
              title: 'Abnormal Detection', 
              desc: 'Instant identification of values outside of standard reference ranges.' 
            },
            { 
              icon: <Zap className="text-blue-500" />, 
              title: 'AI Health Insights', 
              desc: 'Contextual explanations of what your results mean for your health.' 
            },
            { 
              icon: <FileText className="text-purple-500" />, 
              title: 'Simple Explanations', 
              desc: 'No more medical jargon. Get clear, plain-English summaries.' 
            },
            { 
              icon: <ShieldCheck className="text-green-500" />, 
              title: 'Secure Processing', 
              desc: 'Your data is processed securely and never stored without permission.' 
            },
            { 
              icon: <Stethoscope className="text-red-500" />, 
              title: 'Doctor-Ready Reports', 
              desc: 'Organized summaries that you can easily share with your physician.' 
            }
          ].map((feature, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -10 }}
              className="p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:shadow-xl transition-all"
            >
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm mb-6">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-medical-blue mb-3">{feature.title}</h3>
              <p className="text-slate-600 leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
};

const AnalysisPage = ({ onResults, onBack }: { onResults: (data: AnalysisResponse, aiExp: string) => void, onBack: () => void }) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'manual'>('upload');
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<LabValues>({
    gender: 'male'
  });

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    
    const steps = [
      { label: 'Validating Input...', progress: 30 },
      { label: 'Comparing with Reference Dataset...', progress: 60 },
      { label: 'Generating Health Interpretation...', progress: 100 }
    ];

    try {
      setLoadingStep(steps[0].label);
      setProgress(steps[0].progress);
      await new Promise(r => setTimeout(r, 500));

      setLoadingStep(steps[1].label);
      setProgress(steps[1].progress);
      const response = await axios.post('/api/analyze', formData);
      const data = { ...response.data, name: formData.name, age: formData.age };
      
      setLoadingStep(steps[2].label);
      setProgress(steps[2].progress);
      const aiExplanation = await generateAIInterpretation(data);
      
      onResults(data, aiExplanation);
    } catch (err) {
      setError('Failed to analyze data. Please check your inputs.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const generateAIInterpretation = async (data: AnalysisResponse) => {
    const prompt = `
      You are an AI Medical Laboratory Test Interpretation Assistant.
      
      Step 1: Analyze these results for a ${data.gender} patient.
      Results: ${JSON.stringify(data.results)}
      Summary: ${data.summary}
      
      Step 2: Reference standard medical ranges for:
      - CBC (Hemoglobin, RBC, WBC, Platelets, Hematocrit, MCV, MCH, MCHC, RDW)
      - WBC Differential (Neutrophils, Lymphocytes, Monocytes, Eosinophils, Basophils)
      - Liver Function (ALT, AST, ALP, Bilirubin, Albumin, Protein)
      - Kidney Function (Creatinine, Urea, BUN, Uric Acid)
      - Blood Sugar (Fasting, Post Meal, HbA1c)
      - Lipid Profile (Cholesterol, LDL, HDL, Triglycerides, VLDL)
      - Thyroid (TSH, T3, T4)
      - Electrolytes (Sodium, Potassium, Calcium, Chloride, Magnesium)
      - Vitamins (B12, D)
      - Iron Studies (Ferritin, Iron)

      Step 3: Compare each value (already done by backend, but use for context).
      
      Step 4: Generate a report summary.
      
      Step 5: Provide overall health interpretation:
      - All normal -> "Your laboratory report appears NORMAL."
      - 1-2 abnormal -> "Some values are outside the normal range. Medical consultation recommended."
      - Multiple abnormal -> "Your report shows significant abnormalities. Please consult a doctor."
      
      Step 6: Provide simple explanation for abnormal values.
      
      Step 7: For each abnormal parameter, suggest 3-5 specific foods (e.g., for low hemoglobin: Spinach, Lentils, Eggs, Beetroot) and 2-3 lifestyle changes.
      
      Step 8: Output the final response in a professional, empathetic tone. Use Markdown.
      Include a clear medical disclaimer at the end.
    `;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ parts: [{ text: prompt }] }]
      });
      return response.text || "Unable to generate explanation.";
    } catch (err) {
      console.error("AI Error:", err);
      return "The AI assistant is currently unavailable. Please consult the table for your results.";
    }
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    setLoading(true);
    setError(null);

    const steps = [
      { label: 'Preprocessing image (OpenCV)...', progress: 20 },
      { label: 'Extracting text (OCR Engine)...', progress: 40 },
      { label: 'Parsing values (Regex Engine)...', progress: 60 },
      { label: 'Comparing with Reference Dataset...', progress: 80 },
      { label: 'Generating Health Interpretation...', progress: 100 }
    ];

    try {
      // Convert image to base64
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        
        setLoadingStep(steps[0].label);
        setProgress(steps[0].progress);
        await new Promise(r => setTimeout(r, 800)); // Simulate preprocessing

        setLoadingStep(steps[1].label);
        setProgress(steps[1].progress);
        
        const prompt = `
          Extract medical laboratory values from this image. 
          Look for values in these categories:
          - CBC: Hemoglobin, RBC Count, WBC Count, Platelet Count, Hematocrit, MCV, MCH, MCHC, RDW
          - WBC Differential: Neutrophils, Lymphocytes, Monocytes, Eosinophils, Basophils
          - Liver Function: ALT, AST, ALP, Total Bilirubin, Direct Bilirubin, Albumin, Total Protein
          - Kidney Function: Creatinine, Urea, Blood Urea Nitrogen (BUN), Uric Acid
          - Blood Sugar: Fasting Glucose, Post Meal Glucose, HbA1c
          - Lipid Profile: Total Cholesterol, LDL, HDL, Triglycerides, VLDL
          - Thyroid: TSH, T3, T4
          - Electrolytes: Sodium, Potassium, Calcium, Chloride, Magnesium
          - Vitamins: Vitamin B12, Vitamin D
          - Iron Studies: Ferritin, Iron

          Return ONLY a JSON object with these keys (lowercase, using underscores for spaces) and their numeric values. 
          If a value is not found, use null.
          Example: {"hemoglobin": 14.2, "wbc_count": 6500, "fasting_glucose": 95, ...}
        `;

        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: [{
            parts: [
              { text: prompt },
              { inlineData: { data: base64Data, mimeType: file.type } }
            ]
          }]
        });

        try {
          setLoadingStep(steps[2].label);
          setProgress(steps[2].progress);
          const text = response.text || "{}";
          const cleanedText = text.replace(/```json|```/g, '').trim();
          
          let extractedData;
          try {
            extractedData = JSON.parse(cleanedText);
          } catch (e) {
            console.error("JSON Parse Error:", e, cleanedText);
            // Fallback: try to find JSON block manually if AI included extra text
            const jsonMatch = cleanedText.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
              extractedData = JSON.parse(jsonMatch[0]);
            } else {
              throw new Error("Invalid JSON format from AI");
            }
          }
          
          setLoadingStep(steps[3].label);
          setProgress(steps[3].progress);
          const finalValues = { ...extractedData, gender: formData.gender, name: formData.name, age: formData.age };
          const analysisResponse = await axios.post('/api/analyze', finalValues);
          const finalData = { ...analysisResponse.data, name: formData.name, age: formData.age };
          
          setLoadingStep(steps[4].label);
          setProgress(steps[4].progress);
          const aiExplanation = await generateAIInterpretation(finalData);
          
          onResults(finalData, aiExplanation);
          setLoading(false);
        } catch (parseErr) {
          setError('The AI had trouble formatting the data. Please try manual input or a clearer image.');
          setLoading(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError('Failed to process image. Please try manual input.');
      console.error(err);
      setLoading(false);
    }
  }, [formData.gender, onResults]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: { 'image/*': ['.jpeg', '.jpg', '.png'], 'application/pdf': ['.pdf'] },
    multiple: false
  } as any);

  return (
    <div className="pt-24 pb-20 max-w-4xl mx-auto px-4">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-slate-500 hover:text-medical-blue transition-colors mb-8 group"
      >
        <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
        Back to Home
      </button>

      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
        <div className="flex border-b border-slate-100">
          <button 
            onClick={() => setActiveTab('upload')}
            className={cn(
              "flex-1 py-5 font-bold text-lg transition-all flex items-center justify-center gap-2 group relative",
              activeTab === 'upload' ? "text-medical-blue bg-blue-50/50 border-b-2 border-medical-blue" : "text-slate-400 hover:text-slate-600"
            )}
          >
            <Upload size={20} />
            Upload Report
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50 font-normal">
              Upload an image or PDF of your report
            </span>
          </button>
          <button 
            onClick={() => setActiveTab('manual')}
            className={cn(
              "flex-1 py-5 font-bold text-lg transition-all flex items-center justify-center gap-2 group relative",
              activeTab === 'manual' ? "text-medical-blue bg-blue-50/50 border-b-2 border-medical-blue" : "text-slate-400 hover:text-slate-600"
            )}
          >
            <FileText size={20} />
            Manual Input
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50 font-normal">
              Enter your lab values manually
            </span>
          </button>
        </div>

        <div className="p-8">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-700">
              <AlertCircle size={20} />
              <p className="text-sm font-medium">{error}</p>
            </div>
          )}

          {loading ? (
            <div className="py-20 text-center">
              <div className="relative w-24 h-24 mx-auto mb-8">
                <div className="absolute inset-0 border-4 border-slate-100 rounded-full" />
                <motion.div 
                  className="absolute inset-0 border-4 border-medical-blue rounded-full border-t-transparent"
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Activity className="text-medical-blue animate-pulse" size={32} />
                </div>
              </div>
              
              <h3 className="text-2xl font-bold text-slate-800 mb-2">Analyzing Report</h3>
              <p className="text-slate-500 mb-8">{loadingStep}</p>
              
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden mb-4">
                <motion.div 
                  className="h-full bg-medical-blue shadow-lg shadow-blue-500/20"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
              <p className="text-xs font-bold text-medical-blue uppercase tracking-widest">{progress}% Complete</p>
            </div>
          ) : (
            <AnimatePresence mode="wait">
              {activeTab === 'upload' ? (
                <motion.div
                  key="upload"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <div className="mb-6">
                    <label className="block text-sm font-bold text-slate-700 mb-2">Select Gender</label>
                    <div className="flex gap-4">
                      {['male', 'female'].map(g => (
                        <button
                          key={g}
                          onClick={() => setFormData({ ...formData, gender: g as any })}
                          className={cn(
                            "flex-1 py-3 rounded-xl border-2 font-bold capitalize transition-all",
                            formData.gender === g ? "border-medical-blue bg-blue-50 text-medical-blue" : "border-slate-100 text-slate-400 hover:border-slate-200"
                          )}
                        >
                          {g}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div 
                    {...getRootProps()} 
                    className={cn(
                      "border-3 border-dashed rounded-3xl p-12 text-center transition-all cursor-pointer",
                      isDragActive ? "border-medical-blue bg-blue-50" : "border-slate-200 hover:border-slate-300 bg-slate-50"
                    )}
                  >
                    <input {...getInputProps()} />
                    <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center shadow-md mx-auto mb-6">
                      <Upload className="text-medical-blue w-10 h-10" />
                    </div>
                    <h3 className="text-xl font-bold text-medical-blue mb-2">
                      {isDragActive ? "Drop the report here" : "Drag & drop your report"}
                    </h3>
                    <p className="text-slate-500 mb-6">Supports JPG, PNG, and PDF formats</p>
                    <button className="bg-medical-blue text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-blue-900/10">
                      Browse Files
                    </button>
                  </div>
                  <div className="mt-8 flex items-start gap-3 p-4 bg-amber-50 rounded-2xl border border-amber-100">
                    <Info className="text-amber-600 shrink-0" size={20} />
                    <p className="text-xs text-amber-800 leading-relaxed">
                      For best results, ensure the image is clear and all text is legible. Our AI will automatically extract the values for analysis.
                    </p>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="manual"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <form onSubmit={handleManualSubmit} className="space-y-6">
                    <div className="space-y-8">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <label className="block text-sm font-bold text-slate-700 mb-2">Patient Name</label>
                          <input 
                            type="text"
                            placeholder="e.g. John Doe"
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-medical-blue focus:border-transparent outline-none transition-all"
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="block text-sm font-bold text-slate-700 mb-2">Age</label>
                          <input 
                            type="number"
                            placeholder="e.g. 35"
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-medical-blue focus:border-transparent outline-none transition-all"
                            onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) })}
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-sm font-bold text-slate-700 mb-2">Gender</label>
                          <div className="flex gap-4">
                            {['male', 'female'].map(g => (
                              <button
                                key={g}
                                type="button"
                                onClick={() => setFormData({ ...formData, gender: g as any })}
                                className={cn(
                                  "flex-1 py-3 rounded-xl border-2 font-bold capitalize transition-all",
                                  formData.gender === g ? "border-medical-blue bg-blue-50 text-medical-blue" : "border-slate-100 text-slate-400 hover:border-slate-200"
                                )}
                              >
                                {g}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      {[
                        {
                          category: "CBC",
                          fields: [
                            { id: 'hemoglobin', label: 'Hemoglobin (g/dL)', placeholder: 'e.g. 14.2' },
                            { id: 'rbc_count', label: 'RBC Count (million/µL)', placeholder: 'e.g. 5.2' },
                            { id: 'wbc_count', label: 'WBC Count (cells/µL)', placeholder: 'e.g. 7000' },
                            { id: 'platelet_count', label: 'Platelet Count (/µL)', placeholder: 'e.g. 250000' },
                            { id: 'hematocrit', label: 'Hematocrit (%)', placeholder: 'e.g. 42' },
                            { id: 'mcv', label: 'MCV (fL)', placeholder: 'e.g. 90' },
                            { id: 'mch', label: 'MCH (pg)', placeholder: 'e.g. 30' },
                            { id: 'mchc', label: 'MCHC (g/dL)', placeholder: 'e.g. 34' },
                            { id: 'rdw', label: 'RDW (%)', placeholder: 'e.g. 13' },
                          ]
                        },
                        {
                          category: "WBC Differential",
                          fields: [
                            { id: 'neutrophils', label: 'Neutrophils (%)', placeholder: 'e.g. 60' },
                            { id: 'lymphocytes', label: 'Lymphocytes (%)', placeholder: 'e.g. 30' },
                            { id: 'monocytes', label: 'Monocytes (%)', placeholder: 'e.g. 5' },
                            { id: 'eosinophils', label: 'Eosinophils (%)', placeholder: 'e.g. 3' },
                            { id: 'basophils', label: 'Basophils (%)', placeholder: 'e.g. 1' },
                          ]
                        },
                        {
                          category: "Liver Function",
                          fields: [
                            { id: 'alt', label: 'ALT (U/L)', placeholder: 'e.g. 30' },
                            { id: 'ast', label: 'AST (U/L)', placeholder: 'e.g. 25' },
                            { id: 'alp', label: 'ALP (IU/L)', placeholder: 'e.g. 100' },
                            { id: 'total_bilirubin', label: 'Total Bilirubin (mg/dL)', placeholder: 'e.g. 0.8' },
                            { id: 'direct_bilirubin', label: 'Direct Bilirubin (mg/dL)', placeholder: 'e.g. 0.2' },
                            { id: 'albumin', label: 'Albumin (g/dL)', placeholder: 'e.g. 4.2' },
                            { id: 'total_protein', label: 'Total Protein (g/dL)', placeholder: 'e.g. 7.2' },
                          ]
                        },
                        {
                          category: "Kidney Function",
                          fields: [
                            { id: 'creatinine', label: 'Creatinine (mg/dL)', placeholder: 'e.g. 0.9' },
                            { id: 'urea', label: 'Urea (mg/dL)', placeholder: 'e.g. 15' },
                            { id: 'blood_urea_nitrogen', label: 'BUN (mg/dL)', placeholder: 'e.g. 12' },
                            { id: 'uric_acid', label: 'Uric Acid (mg/dL)', placeholder: 'e.g. 5.0' },
                          ]
                        },
                        {
                          category: "Blood Sugar",
                          fields: [
                            { id: 'fasting_glucose', label: 'Fasting Glucose (mg/dL)', placeholder: 'e.g. 90' },
                            { id: 'post_meal_glucose', label: 'Post Meal Glucose (mg/dL)', placeholder: 'e.g. 120' },
                            { id: 'hba1c', label: 'HbA1c (%)', placeholder: 'e.g. 5.2' },
                          ]
                        },
                        {
                          category: "Lipid Profile",
                          fields: [
                            { id: 'total_cholesterol', label: 'Total Cholesterol (mg/dL)', placeholder: 'e.g. 180' },
                            { id: 'ldl', label: 'LDL (mg/dL)', placeholder: 'e.g. 90' },
                            { id: 'hdl', label: 'HDL (mg/dL)', placeholder: 'e.g. 50' },
                            { id: 'triglycerides', label: 'Triglycerides (mg/dL)', placeholder: 'e.g. 130' },
                            { id: 'vldl', label: 'VLDL (mg/dL)', placeholder: 'e.g. 20' },
                          ]
                        },
                        {
                          category: "Thyroid",
                          fields: [
                            { id: 'tsh', label: 'TSH (mIU/L)', placeholder: 'e.g. 2.0' },
                            { id: 't3', label: 'T3 (ng/dL)', placeholder: 'e.g. 150' },
                            { id: 't4', label: 'T4 (µg/dL)', placeholder: 'e.g. 8.0' },
                          ]
                        },
                        {
                          category: "Electrolytes",
                          fields: [
                            { id: 'sodium', label: 'Sodium (mmol/L)', placeholder: 'e.g. 140' },
                            { id: 'potassium', label: 'Potassium (mmol/L)', placeholder: 'e.g. 4.0' },
                            { id: 'calcium', label: 'Calcium (mg/dL)', placeholder: 'e.g. 9.5' },
                            { id: 'chloride', label: 'Chloride (mmol/L)', placeholder: 'e.g. 100' },
                            { id: 'magnesium', label: 'Magnesium (mg/dL)', placeholder: 'e.g. 2.0' },
                          ]
                        },
                        {
                          category: "Vitamins",
                          fields: [
                            { id: 'vitamin_b12', label: 'Vitamin B12 (pg/mL)', placeholder: 'e.g. 500' },
                            { id: 'vitamin_d', label: 'Vitamin D (ng/mL)', placeholder: 'e.g. 35' },
                          ]
                        },
                        {
                          category: "Iron Studies",
                          fields: [
                            { id: 'ferritin', label: 'Ferritin (ng/mL)', placeholder: 'e.g. 100' },
                            { id: 'iron', label: 'Iron (µg/dL)', placeholder: 'e.g. 100' },
                          ]
                        }
                      ].map(cat => (
                        <div key={cat.category} className="space-y-4">
                          <h3 className="text-sm font-bold text-medical-teal uppercase tracking-wider border-b border-slate-100 pb-2">
                            {cat.category}
                          </h3>
                          <div className="grid md:grid-cols-2 gap-6">
                            {cat.fields.map(field => (
                              <div key={field.id}>
                                <label className="block text-sm font-bold text-slate-700 mb-2">{field.label}</label>
                                <input 
                                  type="number"
                                  step="any"
                                  placeholder={field.placeholder}
                                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-medical-blue focus:border-transparent outline-none transition-all"
                                  onChange={(e) => {
                                    const val = e.target.value === "" ? undefined : parseFloat(e.target.value);
                                    setFormData({ ...formData, [field.id]: val });
                                  }}
                                />
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>

                    <button 
                      type="submit"
                      className="w-full bg-medical-blue hover:bg-blue-900 text-white py-4 rounded-xl font-bold text-lg transition-all shadow-xl shadow-blue-900/20 mt-8 group relative"
                    >
                      Analyze Results
                      <span className="absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50 font-normal">
                        Submit values for AI interpretation
                      </span>
                    </button>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          )}
        </div>
      </div>
    </div>
  );
};

const ResultsDashboard = ({ data, aiExplanation, onBack }: { data: AnalysisResponse, aiExplanation: string, onBack: () => void }) => {
  const abnormalCount = data.results.filter(r => r.status !== 'Normal').length;
  const healthScore = Math.max(0, 100 - (abnormalCount * 15));

  const chartData = [
    { name: 'Normal', value: data.results.length - abnormalCount, color: '#38B2AC' },
    { name: 'Abnormal', value: abnormalCount, color: '#EF4444' }
  ].filter(d => d.value > 0);

  return (
    <div className="pt-24 pb-20 max-w-6xl mx-auto px-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-4">
          <div className="bg-medical-blue p-3 rounded-2xl shadow-lg shadow-blue-500/20">
            <Microscope className="text-white" size={24} />
          </div>
          <div>
            <button 
              onClick={onBack}
              className="flex items-center gap-2 text-slate-500 hover:text-medical-blue transition-colors mb-1 group text-sm"
            >
              <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
              New Analysis
            </button>
            <h1 className="text-3xl font-bold text-medical-blue dark:text-blue-400">
              {data.name ? `${data.name}'s Analysis` : "Analysis Dashboard"}
            </h1>
            {data.age && (
              <p className="text-sm text-slate-500 flex items-center gap-2">
                <Users size={14} />
                Patient Age: {data.age} years
              </p>
            )}
          </div>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 bg-white border border-slate-200 px-4 py-2 rounded-xl font-bold text-slate-700 hover:bg-slate-50 transition-all group relative">
            <Download size={18} />
            Download PDF
            <span className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50 font-normal">
              Save results as a PDF document
            </span>
          </button>
          <button className="flex items-center gap-2 bg-medical-teal text-white px-4 py-2 rounded-xl font-bold shadow-lg shadow-teal-500/20 hover:bg-teal-600 transition-all group relative">
            Share Report
            <span className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50 font-normal">
              Share this analysis with others
            </span>
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Summary Cards and Table */}
        <div className="lg:col-span-2 space-y-8">
          <div className="grid md:grid-cols-2 gap-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-lg border border-slate-100 dark:border-slate-800 flex items-center gap-6"
            >
              <div className="relative w-24 h-24">
                <svg className="w-full h-full" viewBox="0 0 36 36">
                  <path
                    className="text-slate-100 stroke-current"
                    strokeWidth="3"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <motion.path
                    initial={{ strokeDasharray: "0, 100" }}
                    animate={{ strokeDasharray: `${healthScore}, 100` }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                    className={cn("stroke-current", healthScore > 80 ? "text-teal-500" : "text-orange-500")}
                    strokeWidth="3"
                    strokeLinecap="round"
                    fill="none"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-slate-800 dark:text-white">{healthScore}</span>
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Score</span>
                </div>
              </div>
              <div>
                <h3 className="font-bold text-slate-800 dark:text-white text-lg">Health Index</h3>
                <p className="text-sm text-slate-500">Based on your current lab values.</p>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-lg border border-slate-100 dark:border-slate-800 flex items-center gap-6"
            >
              <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center text-medical-blue">
                <Activity size={32} />
              </div>
              <div>
                <h3 className="font-bold text-slate-800 dark:text-white text-lg">{data.summary}</h3>
                <p className="text-sm text-slate-500">Analysis of {data.results.length} parameters.</p>
              </div>
            </motion.div>
          </div>

          {/* Results Table */}
          <div className={cn(
            "bg-white dark:bg-slate-900 rounded-3xl shadow-lg border border-slate-100 dark:border-slate-800 overflow-hidden",
            "transition-colors duration-300"
          )}>
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4">
              <h3 className="font-bold text-slate-800 dark:text-white text-lg">Detailed Parameters</h3>
              <div className="flex flex-wrap gap-2">
                <div className="flex items-center gap-1 text-[10px] font-bold text-teal-600 bg-teal-50 dark:bg-teal-900/20 px-2 py-1 rounded-md">
                  <div className="w-2 h-2 rounded-full bg-teal-500" /> Normal
                </div>
                <div className="flex items-center gap-1 text-[10px] font-bold text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-2 py-1 rounded-md">
                  <div className="w-2 h-2 rounded-full bg-amber-500" /> Borderline
                </div>
                <div className="flex items-center gap-1 text-[10px] font-bold text-red-600 bg-red-50 dark:bg-red-900/20 px-2 py-1 rounded-md">
                  <div className="w-2 h-2 rounded-full bg-red-500" /> Abnormal
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider">
                    <th className="px-6 py-4">Parameter</th>
                    <th className="px-6 py-4">Value</th>
                    <th className="px-6 py-4">Reference Range</th>
                    <th className="px-6 py-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {data.results.map((result, i) => (
                    <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex flex-col gap-1">
                          <span className="font-bold text-slate-700 dark:text-slate-200">{result.parameter}</span>
                          <span className="text-[10px] text-slate-400 font-medium">{result.category}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col gap-2">
                          <span className="font-mono text-slate-600 dark:text-slate-400 font-bold">{result.value} {result.unit}</span>
                          <RangeIndicator 
                            value={result.value} 
                            min={result.min} 
                            max={result.max} 
                            status={result.status}
                            darkMode={false} // Handled by CSS classes
                          />
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-slate-500 dark:text-slate-500 text-sm font-medium">{result.range} {result.unit}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-[10px] font-bold inline-flex items-center gap-1",
                          result.status === 'Normal' ? "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400" : 
                          result.status === 'Borderline' ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400" :
                          "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                        )}>
                          {result.status === 'Normal' ? <CheckCircle2 size={10} /> : <AlertCircle size={10} />}
                          {result.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* New Parameter Comparison Section - Moved to Main Column */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-lg border border-slate-100 dark:border-slate-800"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-xl font-bold text-slate-800 dark:text-white">Parameter Distribution</h3>
                <p className="text-sm text-slate-500">Visual comparison of your results against normal medical ranges.</p>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-xl">
                <Activity className="text-medical-blue" size={24} />
              </div>
            </div>
            
            <ParameterBarChart data={data.results} darkMode={false} />
            
            <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {data.results.slice(0, 9).map((result, i) => (
                <div key={i} className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">{result.parameter}</h4>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">{result.category}</p>
                    </div>
                    <span className={cn(
                      "px-2 py-0.5 rounded-md text-[9px] font-bold uppercase",
                      result.status === 'Normal' ? "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400" : 
                      result.status === 'Borderline' ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400" :
                      "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                    )}>
                      {result.status}
                    </span>
                  </div>
                  <div className="flex justify-between items-end">
                    <span className="text-lg font-bold text-medical-blue">{result.value} <span className="text-[10px] text-slate-400 font-normal">{result.unit}</span></span>
                    <span className="text-[10px] text-slate-400">Range: {result.range}</span>
                  </div>
                  <RangeIndicator 
                    value={result.value} 
                    min={result.min} 
                    max={result.max} 
                    status={result.status}
                    darkMode={false}
                  />
                </div>
              ))}
            </div>
          </motion.div>

          {/* Actionable Health Tips Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-medical-blue to-blue-900 p-8 rounded-3xl shadow-xl text-white relative overflow-hidden"
          >
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                  <HeartPulse className="text-teal-400" size={28} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">Actionable Health Plan</h3>
                  <p className="text-blue-200 text-sm">Personalized nutrition and lifestyle recommendations.</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h4 className="font-bold text-lg flex items-center gap-2">
                    <CheckCircle2 className="text-teal-400" size={20} />
                    Nutrition Guidance
                  </h4>
                  <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/10">
                    <p className="text-sm leading-relaxed text-blue-50">
                      Based on your {abnormalCount > 0 ? 'abnormal' : 'current'} results, focus on incorporating more nutrient-dense foods. 
                      {data.results.some(r => r.parameter.toLowerCase().includes('hemoglobin') && r.status !== 'Normal') && 
                        " For your hemoglobin levels, prioritize iron-rich foods like spinach, lentils, and lean proteins."}
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {['Leafy Greens', 'Lean Protein', 'Antioxidants', 'Hydration'].map(tag => (
                        <span key={tag} className="px-3 py-1 bg-teal-500/20 rounded-full text-[10px] font-bold uppercase tracking-wider border border-teal-500/30">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-bold text-lg flex items-center gap-2">
                    <Zap className="text-amber-400" size={20} />
                    Lifestyle Adjustments
                  </h4>
                  <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/10">
                    <ul className="space-y-3">
                      {[
                        "Maintain consistent sleep patterns (7-9 hours).",
                        "Incorporate 30 mins of moderate physical activity.",
                        "Monitor hydration levels throughout the day.",
                        "Schedule a follow-up consultation if values persist."
                      ].map((tip, i) => (
                        <li key={i} className="flex items-start gap-3 text-sm text-blue-50">
                          <div className="w-1.5 h-1.5 rounded-full bg-teal-400 mt-1.5 shrink-0" />
                          {tip}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-white/5 rounded-full blur-3xl" />
          </motion.div>
        </div>

        {/* AI Interpretation Sidebar */}
        <div className="space-y-8">
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-medical-blue text-white p-8 rounded-3xl shadow-xl relative overflow-hidden"
          >
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                  <Zap size={24} className="text-teal-400" />
                </div>
                <h3 className="text-xl font-bold">AI Interpretation</h3>
              </div>
              
              <div className="prose prose-invert prose-sm max-w-none">
                <div className="text-blue-100 leading-relaxed">
                  <ReactMarkdown>{aiExplanation}</ReactMarkdown>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-white/10">
                <div className="flex items-start gap-3 text-xs text-blue-300 italic">
                  <Info size={16} className="shrink-0" />
                  <p>This AI tool provides informational insights only and is not a medical diagnosis. Always consult with a qualified healthcare professional.</p>
                </div>
              </div>
            </div>
            
            {/* Background decoration */}
            <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-teal-500/20 rounded-full blur-3xl" />
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-lg border border-slate-100 dark:border-slate-800"
          >
            <h3 className="font-bold text-slate-800 dark:text-white mb-4">Status Overview</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1e293b', 
                      border: 'none', 
                      borderRadius: '12px', 
                      color: '#fff',
                      fontSize: '12px'
                    }} 
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-6 mt-4">
              {chartData.map((d, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }} />
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-400">{d.name}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [path, setPath] = useState('landing');
  const [results, setResults] = useState<AnalysisResponse | null>(null);
  const [aiExp, setAiExp] = useState<string>('');
  const [darkMode, setDarkMode] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleAnalysisResults = (data: AnalysisResponse, explanation: string) => {
    setResults(data);
    setAiExp(explanation);
    setPath('results');
  };

  return (
    <div className={cn(
      "min-h-screen transition-colors duration-300",
      darkMode ? "bg-slate-950 text-slate-100" : "bg-gray-50 text-slate-900"
    )}>
      <Navbar 
        onNavigate={setPath} 
        currentPath={path} 
        darkMode={darkMode}
        toggleDarkMode={() => setDarkMode(!darkMode)}
        onOpenHelp={() => setIsHelpOpen(true)}
      />
      
      <main>
        <AnimatePresence mode="wait">
          {path === 'landing' && (
            <motion.div
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <LandingPage onStart={() => setPath('analysis')} onNavigate={setPath} darkMode={darkMode} />
            </motion.div>
          )}

          {path === 'analysis' && (
            <motion.div
              key="analysis"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <AnalysisPage 
                onResults={handleAnalysisResults} 
                onBack={() => setPath('landing')} 
              />
            </motion.div>
          )}

          {path === 'comparison' && (
            <motion.div
              key="comparison"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <ComparisonPage onBack={() => setPath('landing')} darkMode={darkMode} />
            </motion.div>
          )}

          {path === 'results' && results && (
            <motion.div
              key="results"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <ResultsDashboard 
                data={results} 
                aiExplanation={aiExp} 
                onBack={() => setPath('analysis')} 
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <HelpModal isOpen={isHelpOpen} onClose={() => setIsHelpOpen(false)} darkMode={darkMode} />
      <ChatAssistant darkMode={darkMode} />

      <footer className={cn(
        "py-12 border-t mt-20",
        darkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"
      )}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <div className="bg-medical-blue p-2 rounded-lg">
                  <Activity className="text-white w-5 h-5" />
                </div>
                <span className="font-bold text-xl tracking-tight text-medical-blue">LabAI Assistant</span>
              </div>
              <p className="text-slate-500 text-sm leading-relaxed">
                Empowering patients with AI-driven insights to better understand their health data and lab results.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-slate-800 mb-6 uppercase text-xs tracking-widest">Quick Links</h4>
              <ul className="space-y-4 text-sm text-slate-500">
                <li><a href="#" className="hover:text-medical-blue transition-colors">How it Works</a></li>
                <li><a href="#" className="hover:text-medical-blue transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-medical-blue transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-medical-blue transition-colors">Contact Support</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-slate-800 mb-6 uppercase text-xs tracking-widest">Medical Disclaimer</h4>
              <p className="text-slate-400 text-xs leading-relaxed">
                This application is for informational purposes only. It does not provide medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition.
              </p>
            </div>
          </div>
          <div className="pt-8 border-t border-slate-100 text-center text-slate-400 text-xs">
            © 2026 LabAI Assistant. All rights reserved. Built with advanced AI for a healthier world.
          </div>
        </div>
      </footer>
    </div>
  );
}
